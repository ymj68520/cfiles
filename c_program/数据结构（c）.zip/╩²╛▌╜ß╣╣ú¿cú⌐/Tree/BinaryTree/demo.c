#include "BinaryTree.h"

int main(){
    BiTree T;
    CreatBiTree(&T);
    PreOrderTraverse(T,Visit);
    return 0;
}

