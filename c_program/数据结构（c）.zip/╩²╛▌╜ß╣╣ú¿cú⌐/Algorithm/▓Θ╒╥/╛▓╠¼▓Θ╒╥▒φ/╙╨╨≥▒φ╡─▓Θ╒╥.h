#include <stdlib.h>
#include <stdio.h>

typedef int KeyType;    // 定义关键字域为整型
typedef struct ElemType{    // 数据元素类型
    KeyType key;    // 仅有关键字域
}ElemType;

