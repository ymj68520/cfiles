#ads

$$\Phi$$

```mermaid
graph LR
a-->d
1{2}-->dd
ff==>a
```
