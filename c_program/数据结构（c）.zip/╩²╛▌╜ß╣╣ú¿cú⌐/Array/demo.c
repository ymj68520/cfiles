#include <stdio.h>
#include <stdbool.h>

bool test(){
    return -1;
}

int main (){
    printf("%d\n",test());
    return 0;
}