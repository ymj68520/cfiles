#include <stdio.h>
#include "stack.h"

int main (){
    
}