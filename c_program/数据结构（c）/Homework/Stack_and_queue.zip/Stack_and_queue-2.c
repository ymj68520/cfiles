#include <stdio.h>
#include <stdlib.h>

int main(){
    int xiao,zhong,da;
    da=xiao=zhong = 0;
    char ch;
    while((ch = getchar())!='#'){
        switch(ch){
            case '{':
                da++;
                break;
            case '[':
                zhong++;
                break;
            case '(':
                xiao++;
                break;
            case ')' :
                xiao --;
                if(xiao<0){
                    puts("ERROR!");
                    return 0;
                }
                break;
            case ']':
                zhong --;
                if(zhong<0){
                    puts("ERROR!");
                    return 0;
                }
                break;
            case '}':
                da--;
                if(da<0){
                    puts("ERROR!");
                    return 0;
                }
                break;
            default:
                puts("Error input : ");
                putchar(ch);
                break;
        }
    }
    puts("OK");
    return 0;
}