#include "thread_hdr.h"

void add_ready_thread(thread* ready_thread)
{
	// 相应的代码实现
}

void current_thread_finished()
{
    // 相应的代码实现
}

void current_thread_blocked()
{
    // 相应的代码实现
}

void notify()
{
    // 相应的代码实现
}

void notify_all()
{
    // 相应的代码实现
}

void on_clock()
{
    // 相应的代码实现
}

void set_first_time_ticks(unsigned int ticks)
{
    // 相应的代码实现
}

void set_second_time_ticks(unsigned int ticks)
{
    // 相应的代码实现
}

void set_time_interval(unsigned int interval)
{
    // 相应的代码实现
}